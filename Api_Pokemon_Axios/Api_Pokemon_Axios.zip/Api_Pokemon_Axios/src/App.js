import './App.css';
import Pokemon from './components/Pokemon'
import axios from 'axios';

function App() {
  return (
    <div className="App">
     <Pokemon></Pokemon>
    </div>
  );
}

export default App;
