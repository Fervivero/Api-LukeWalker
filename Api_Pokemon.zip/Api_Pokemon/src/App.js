import './App.css';
import Pokemon from './components/Pokemon'

function App() {
  return (
    <div className="App">
     <Pokemon></Pokemon>
    </div>
  );
}

export default App;
